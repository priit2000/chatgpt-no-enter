// --- START OF FILE content.js ---

(() => {
  console.log("[NoEnter] Extension loaded v1.12");

  function patchChatGPT() {
    if (!window.location.hostname.includes("chatgpt.com") && !window.location.hostname.includes("chat.openai.com")) return;
    if (window.__noEnterChatGPTPatched) return;
    window.__noEnterChatGPTPatched = true;

    const handler = (event) => {
      if (event.key !== "Enter" || event.isComposing) return;

      const target = event.target;
      const proseMirror = target.closest?.(".ProseMirror") || target.closest?.("#prompt-textarea");
      const textarea = target.tagName === "TEXTAREA" &&
                       (target.id === "mobile-composer-prompt" || target.id === "prompt-textarea" || target.name === "prompt")
                       ? target : null;
      if (!proseMirror && !textarea) return;

      const isMac = navigator.platform.toUpperCase().includes("MAC");
      const ctrlOrCmd = isMac ? event.metaKey : event.ctrlKey;

      if (ctrlOrCmd) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        // Send as-is, without touching the editor content
        const sendButton = document.querySelector("#composer-submit-button") ||
                           document.querySelector('[data-testid="send-button"]') ||
                           document.querySelector('button[aria-label="Send message"]');
        if (sendButton) sendButton.click();
        return false;
      }

      if (event.shiftKey) return;

      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();

      if (textarea) {
        document.execCommand("insertText", false, "\n");
        console.log("[NoEnter] ChatGPT: newline inserted (textarea)");
        return false;
      }

      // Let the editor handle it as Shift+Enter, so it creates the newline itself
      const before = proseMirror.innerHTML;
      target.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter", code: "Enter", keyCode: 13, which: 13,
        shiftKey: true, bubbles: true, cancelable: true
      }));
      if (proseMirror.innerHTML === before) document.execCommand("insertParagraph", false);
      console.log("[NoEnter] ChatGPT: newline inserted");
      return false;
    };

    document.addEventListener("keydown", handler, { capture: true, passive: false });
    console.log("[NoEnter] ChatGPT patched (document level)");
  }

  function patchGemini() {
    if (!window.location.hostname.includes("gemini.google.com")) return;
    if (window.__noEnterGeminiPatched) return;
    window.__noEnterGeminiPatched = true;

    const handler = (event) => {
      if (event.key !== "Enter") return;
      
      const target = event.target;
      const isGeminiInput = target.closest(".ql-editor") || 
                            target.closest("rich-textarea") || 
                            target.closest(".input-area") ||
                            (target.isContentEditable && target.closest("[data-placeholder]"));
      if (!isGeminiInput) return;

      const isMac = navigator.platform.toUpperCase().includes("MAC");
      const ctrlOrCmd = isMac ? event.metaKey : event.ctrlKey;

      if (ctrlOrCmd) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        const sendButton = document.querySelector('[aria-label="Send message"]') || 
                          document.querySelector('button.send-button') ||
                          document.querySelector('[data-test-id="send-button"]');
        if (sendButton) sendButton.click();
        return false;
      }

      if (!event.shiftKey) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        document.execCommand("insertParagraph", false);
        console.log("[NoEnter] Gemini: newline inserted");
        return false;
      }
    };

    document.addEventListener("keydown", handler, { capture: true, passive: false });
    window.addEventListener("keydown", handler, { capture: true, passive: false });
    console.log("[NoEnter] Gemini patched (window+document level)");
  }

  function patchClaude() {
    if (window.location.hostname !== "claude.ai" || window.__noEnterClaudePatched) return;
    window.__noEnterClaudePatched = true;

    const handler = (event) => {
      if (event.key !== "Enter") return;
      const target = event.target;
      if (!target.closest('[data-testid="chat-input"]') && !target.closest('.ProseMirror')) return;

      const isMac = navigator.platform.toUpperCase().includes("MAC");
      const ctrlOrCmd = isMac ? event.metaKey : event.ctrlKey;

      if (ctrlOrCmd) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        const sendBtn = document.querySelector('button[aria-label="Send message"]');
        if (sendBtn) sendBtn.click();
        return false;
      }

      if (!event.shiftKey) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        document.execCommand("insertParagraph", false);
        console.log("[NoEnter] Claude: newline inserted");
        return false;
      }
    };

    document.addEventListener("keydown", handler, { capture: true, passive: false });
    window.addEventListener("keydown", handler, { capture: true, passive: false });
    console.log("[NoEnter] Claude patched (window+document level)");
  }

  function patchCopilot() {
    if (!window.location.hostname.includes("copilot.microsoft.com")) return;
    if (window.__noEnterCopilotPatched) return;
    window.__noEnterCopilotPatched = true;

    const handler = (event) => {
      if (event.key !== "Enter") return;

      const target = event.target;
      const isCopilotInput = target.id === "userInput" ||
                             target.closest('[data-testid="composer-input"]') ||
                             target.closest('[data-testid="composer-content"]');
      if (!isCopilotInput) return;

      const isMac = navigator.platform.toUpperCase().includes("MAC");
      const ctrlOrCmd = isMac ? event.metaKey : event.ctrlKey;

      if (ctrlOrCmd) {
        // No send button in Copilot - let the native Enter through by not blocking
        return;
      }

      if (!event.shiftKey) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        const textarea = target.tagName === "TEXTAREA" ? target : document.getElementById("userInput");
        if (textarea) {
          const start = textarea.selectionStart;
          const end = textarea.selectionEnd;
          const value = textarea.value;
          textarea.value = value.substring(0, start) + "\n" + value.substring(end);
          textarea.selectionStart = textarea.selectionEnd = start + 1;
          textarea.dispatchEvent(new InputEvent("input", { bubbles: true }));
          console.log("[NoEnter] Copilot: newline inserted");
        }
        return false;
      }
    };

    document.addEventListener("keydown", handler, { capture: true, passive: false });
    window.addEventListener("keydown", handler, { capture: true, passive: false });
    console.log("[NoEnter] Copilot patched (window+document level)");
  }

  function patchGrok() {
    if (!window.location.hostname.includes("grok.com")) return;
    if (window.__noEnterGrokPatched) return;
    window.__noEnterGrokPatched = true;

    const isGrokEditor = (target) =>
      target.classList?.contains("ProseMirror") || target.closest(".ProseMirror") ||
      target.closest(".query-bar") || target.closest(".tiptap");

    const handler = (event) => {
      if (event.key !== "Enter") return;
      if (!isGrokEditor(event.target)) return;

      const isMac = navigator.platform.toUpperCase().includes("MAC");
      const ctrlOrCmd = isMac ? event.metaKey : event.ctrlKey;

      if (ctrlOrCmd) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        const sendBtn = document.querySelector('button[aria-label="Submit"]') ||
                        document.querySelector('button[type="submit"]');
        if (sendBtn) sendBtn.click();
        return false;
      }

      if (!event.shiftKey) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        return false;
      }
    };

    const insertNewline = (event) => {
      if (event.key !== "Enter") return;
      if (!isGrokEditor(event.target)) return;

      const isMac = navigator.platform.toUpperCase().includes("MAC");
      const ctrlOrCmd = isMac ? event.metaKey : event.ctrlKey;

      if (!ctrlOrCmd && !event.shiftKey) {
        const editor = event.target.closest(".ProseMirror") || event.target;
        const sel = window.getSelection();
        if (sel.rangeCount > 0) {
          const range = sel.getRangeAt(0);
          range.deleteContents();
          const br = document.createElement("br");
          range.insertNode(br);
          range.setStartAfter(br);
          range.setEndAfter(br);
          sel.removeAllRanges();
          sel.addRange(range);
          editor.dispatchEvent(new InputEvent("input", { bubbles: true }));
          console.log("[NoEnter] Grok: newline inserted via keyup");
        }
      }
    };

    document.addEventListener("keydown", handler, { capture: true, passive: false });
    window.addEventListener("keydown", handler, { capture: true, passive: false });
    document.addEventListener("keyup", insertNewline, { capture: true, passive: false });
    console.log("[NoEnter] Grok patched (window+document level)");
  }

  patchChatGPT();
  patchGemini();
  patchClaude();
  patchCopilot();
  patchGrok();

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      patchChatGPT();
      patchGemini();
      patchClaude();
      patchCopilot();
      patchGrok();
    });
  }
})();

// --- END OF FILE content.js ---
